import cv2
import numpy as np


# 顯示圖片
def showimg(ig):
    cv2.imshow('image', ig)
    cv2.waitKey(0)


# 讀取圖片
img = cv2.imread('lena.bmp')
# 取得圖片的寬度和高度
height, width = img.shape[:2]
# 創建三個空白的圖片，與原始圖片大小相同
upside_down = np.zeros_like(img)
right_side_left = np.zeros_like(img)
diagonally_flip = np.zeros_like(img)

# 進行上下翻轉操作
for i in range(height):
    for j in range(width):
        upside_down[i, j] = img[height - i - 1, j]
# 進行水平翻轉操作
for i in range(height):
    for j in range(width):
        right_side_left[i, j] = img[i, width - 1 - j]
# 進行對角線翻轉操作
for i in range(height):
    for j in range(width):
        diagonally_flip[i, j] = img[height - i - 1, width - 1 - j]

showimg(img)
showimg(upside_down)
showimg(right_side_left)
showimg(diagonally_flip)

# 對圖片進行二值化處理
th, im_th = cv2.threshold(img, 128, 255, cv2.THRESH_BINARY)
showimg(im_th)
